# POSTERIOR DISPERSION INDICES

This folder contains code to replicate:

**Section 2.1:** motivating case study of U.S. presidents

**Figure 3:** not all predictive probabilities are created equal

**Section 3.1:** voting preferences logistic regression

